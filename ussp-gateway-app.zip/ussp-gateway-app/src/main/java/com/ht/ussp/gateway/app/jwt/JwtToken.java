package com.ht.ussp.gateway.app.jwt;

public interface JwtToken {
    String getToken();
}
