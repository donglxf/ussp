package com.ht.ussp.gateway.app.exception;

/**
 * 
 * @ClassName: InvalidJwtToken
 * @Description: TODO
 * @author wim qiuwenwu@hongte.info
 * @date 2018年1月6日 上午11:31:52
 */
public class InvalidJwtToken extends RuntimeException {
    private static final long serialVersionUID = -294671188037098603L;
}
